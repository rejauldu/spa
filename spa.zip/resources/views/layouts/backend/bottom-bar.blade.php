@computer
<footer class="main-footer text-center">
	<div class="float-right">
		{{ __('Developed by') }} <b>rejauldu</b>
	</div>
	<strong>{{ __('Copyright') }} © {{ __(date('Y')) }} <a href="#">{{ config('app.name', 'Laravel') }}</a>.</strong> {{ __('All rights reserved') }}
</footer>
@endcomputer