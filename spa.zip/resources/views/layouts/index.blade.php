@include('layouts.frontend.header')
@yield('content')
@include('layouts.frontend.footer')